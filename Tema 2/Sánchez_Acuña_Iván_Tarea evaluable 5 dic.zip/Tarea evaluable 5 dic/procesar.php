<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $usuario_correcto = 'Iván';
        $usuario =null;

        if (isset($_COOKIE['usuario'])) {
            $usuario = $_COOKIE['usuario'];
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $usuario = $_POST['usuario'];

            if ($usuario === $usuario_correcto) {
                setcookie('usuario', $usuario, time() + 3600, '/');
            } else {
                echo "Usuario o contraseña incorrectos.";
                $usuario = null;
            }
        }

        session_start();

        $contraseña = "12345";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $clave = $_POST['clave'];
            

            if ($clave === $contraseña) {
                $_SESSION['clave'] = $contraseña; 
                header ("Location:bienvenida.php");
            }
        
        }

        function visitas() 
        
        {if (isset($_COOKIE['numero_visitas'])) {
            $visitas = $_COOKIE['numero_visitas'] + 1;
        } else {
            $visitas = 1; 
        }

        setcookie('numero_visitas', $visitas, time() + (86400 * 30), "/"); 


        echo "Esta es tu " . $visitas . " visita.";
    }
    ?>
</body>
</html>